package seminar01.weapons;

public class Weapons {
    protected String name;

    protected int damage;

    protected int maxDamage;

    protected int range;
}